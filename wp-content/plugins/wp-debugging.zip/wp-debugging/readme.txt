# WP Debugging

Contributors: afragen
Tags: debug, support, wp-config
Requires at least: 4.6
Requires PHP: 5.6
Tested up to: 5.5
Stable tag: 2.7.2
Donate link: https://thefragens.com/github-updater-donate
License: MIT

A support/troubleshooting plugin for WordPress.

## Description

This plugin sets the following debug constants in `wp-config.php` on plugin activation and removes them on plugin deactivation. Any errors will result in a PHP Exception being thrown. Debug constants per [Debugging in WordPress](https://codex.wordpress.org/Debugging_in_WordPress).

Default settings:

    define( 'WP_DEBUG_LOG', true );
    define( 'SCRIPT_DEBUG', true );
    define( 'SAVEQUERIES', true );

&nbsp;
`@ini_set( 'display_errors', 1 );` is set when the plugin is active. `WP_DEBUG` is set to true when the plugin is first run, thereafter it can be turned off in the Settings.

The Settings page allows the user to set the following.

    define( 'WP_DEBUG', true ); // Default on initial plugin installation.
    define( 'WP_DEBUG_DISPLAY', false ); // Default when not declared is true.
    define( 'WP_DISABLE_FATAL_ERROR_HANDLER', true ); // WordPress 5.2 WSOD Override.

When the plugin is deactivated best efforts are made to re-add pre-existing constants to their former state. When the plugin is activated the default settings and any saved settings are restored.

This plugin uses the [wp-cli/wp-config-transformer](https://github.com/wp-cli/wp-config-transformer) command for writing constants to `wp-config.php`.

[Debug Quick Look](https://github.com/norcross/debug-quick-look) from Andrew Norcross is included with this plugin to assist in reading the debug.log file. If you already have this plugin installed you should delete it when WP Debugging is not active.

[Query Monitor](https://wordpress.org/plugins/query-monitor/) and [Debug Bar](https://wordpress.org/plugins/debug-bar/) plugins are optional dependencies to aid in debugging and troubleshooting. The notice for installation will recur 45 days after being dismissed.

If you have a non-standard location for your `wp-config.php` file you can use the filter `wp_debugging_config_path` to return the file path for your installation.

The filter `wp_debugging_add_constants` allows the user to add constants to `wp-config.php`.

The filter returns an array where the key is the name of the constant and the value is an array of data containing the value as a string and a boolean to indicate whether or not the value should be passed without quotes.

    $my_constants = [
        'my_test_constant' =>
        [
            'value' => 'abc123',
            'raw' => false,
        ],
        'another_test_constant' => [ 'value' => 'true' ],
    ];

The `value` option contains the constant's value as a string.

The `raw` option means that instead of placing the value inside the config as a string it will become unquoted. The default is `true`. Set as `false` for non-boolean values.

Example:

    add_filter(
	    'wp_debugging_add_constants',
	    function( $added_constants ) {
	    	$my_constants = [
	    		'my_test_constant'      => [
	    			'value' => '124xyz',
	    			'raw'   => false,
	    		],
	    		'another_test_constant' => [ 'value' => 'true' ],
	    	];
	    	return array_merge( $added_constants, $my_constants );
	    },
	    10,
	    1
    );

This will create the following constants.

    define( 'MY_TEST_CONSTANT', '124xyz' );
    define( 'ANOTHER_TEST_CONSTANT', true );

## Screenshots

1. Settings Screen

## Development

PRs are welcome against the [develop branch on GitHub](https://github.com/afragen/wp-debugging).

## Changelog

#### 2.7.2 / 2020-06-01
* test `wp-config.php` everywhere, still occaisional WSOD reports.

#### 2.7.1 / 2020--5-15
* return early if `wp-config.php` is empty before calling `WPConfigTransformer`

#### 2.7.0 / 2020-04-30
* start loading in `init` hook
* run `process_filter_constants()` as chained method in `Bootstrap`

#### 2.6.1 / 2020-03-28
* move `Settings` action link to front
* change test for `wp-config.php` file empty

#### 2.6.0 / 2020-02-28
* load autoloader in main file
* update composer dependencies

#### 2.5.8 / 2019-12-23
* badly messed up check for empty `wp-config.php`

#### 2.5.7 / 2019-12-20
* check and exit early if `wp-config.php` is empty
* return empty array for the above exit

#### 2.5.6 / 2019-11-02
* early exit if `wp-config.php` not set in specific functions

#### 2.5.5 / 2019-09-17
* update composer.json for wp-dependency-installer update, now requires at least PHP 5.6 for spread operator
* composer update

#### 2.5.4 / 2019-04-25
* added check for writable `wp-config.php`, exit with notice if not found

#### 2.5.3 / 2019-04-01
* update `Debug Quick Look` to display error log file path

#### 2.5.1 / 2019-04-01
* updated version of wp-cli/wp-config-transformer

#### 2.5.0 / 2019-03-25
* added `wp_debugging_add_constants` filter for users to add their own constants

#### 2.4.3 / 2019-03-09
* missed an output escape

#### 2.4.2 / 2019-02-26
* add `Domain Path` header

#### 2.4.1 / 2019-02-10
* refactor set/restore pre-activation constants

#### 2.4.0 / 2019-02-06
* save pre-activation constants for re-installation on deactivation ( say that 5x fast )

#### 2.3.0 / 2019-02-04
* look for `wp-config.php` in directory above `ABSPATH`
* add filter `wp_debugging_config_path` to set non-standard path to `wp-config.php`

#### 2.2.0 / 2019-02-02 🏈
* initial release on dot org

#### 2.1.1 / 2019-02-01
* only show WSOD bypass when appropriate
* update dependencies

#### 2.1.0 / 2019-01-26
* update Debug Quick Look, minor CSS changes
* Improve messaging
* add setting for WP_DISABLE_FATAL_ERROR_HANDLER constant (WSOD)
* add default setting of WP_DEBUG to true, can be changed

#### 2.0.0 / 2019-01-18
* total re-write
* add settings page
* use `wp-cli/wp-config-transformer` to change `wp-config.php`
* include `norcross/debug-quick-look` as dependency via composer but use my fork
* update POT via `composer.json` and wp-cli
* add image assets
